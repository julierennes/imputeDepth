################################################################################
## File:             imputation.R                                             ##
## Created by:       Pavlo Mozharovskyi                                       ##
## Last revised:     23.12.2016                                               ##
##                                                                            ##
## Contains functions for depth-based imputation.                             ##
##                                                                            ##
################################################################################

kth <- function(x, k){
  a <- .C("KthElement",
          as.double(x),
          as.integer(length(x)),
          as.integer(k),
          kthel = double(1))
  return (a$kthel)
}

imputeEllP <- function(point, Sigma.inv){
  point.new <- point
  d <- length(point)
  index <- which(is.na(point))
  if (length(index) == 1){
    point.new[index] <- -point.new[-index] %*% Sigma.inv[index,-index] /
      Sigma.inv[index,index]
  }else{
    index <- which(is.na(point))
    A <- Sigma.inv[index,index]
    b <- -Sigma.inv[index,(1:d)[-index], drop = FALSE] %*% point[-index]
    point.new[index] <- solve(A) %*% b
  }
  return (point.new)
}

imp.depth.Mahalanobis <- function(X, num.iter = 100, X.start = NULL, alpha = 1,
                                  mu = NULL, Sigma = NULL){
  if (!is.null(mu) && !is.null(Sigma)){
    miss <- which(is.na(X), arr.ind=T)
    X.prep <- X
    X.prep <- t(t(X.prep) - mu)
    Inv.Sigma <- solve(Sigma)
    miss.rowi <- unique(miss[,1])
    X.new <- X.prep
    X.new <- X.new[miss.rowi,,drop=FALSE]
    X.prep[miss.rowi,] <- t(apply(X.new, 1, imputeEllP, Inv.Sigma))
    X.prep <- t(t(X.prep) + mu)
    return(X.prep)
  }
  if (is.null(X.start)){
    X.prep <- X
    miss.label <- is.na(X.prep)
    # TODO: The following line is dangerous when each observation has missings
    X.prep[miss.label] <- matrix(rep(colMeans(X.prep, na.rm = TRUE),
                                     nrow(X.prep)), nrow = nrow(X.prep),
                                 byrow = TRUE)[miss.label] +
      rnorm(n = sum(miss.label), mean = 0, sd = 0.001)
  }else{
    X.prep <- X.start
  }
  miss <- which(is.na(X), arr.ind=T)
  for (i in 1:num.iter){
    if (alpha > 0.99){
      mu.tmp <- colMeans(X.prep)
      Sigma.tmp <- cov(X.prep)
    }else{
      mcd.est <- covMcd(X.prep, alpha = alpha)
      mu.tmp <- mcd.est$center
      Sigma.tmp <- mcd.est$cov
    }
    X.prep <- t(t(X.prep) - mu.tmp)
    Inv.Sigma.tmp <- solve(Sigma.tmp)
    miss.rowi <- unique(miss[,1])
    X.new <- X.prep
    X.new[miss] <- NA
    X.new <- X.new[miss.rowi,,drop=FALSE]
    X.prep[miss.rowi,] <- t(apply(X.new, 1, imputeEllP, Inv.Sigma.tmp))
    X.prep <- t(t(X.prep) + mu.tmp)
  }
  return (X.prep)
}

imp.depth.spatial <- function(X){
  Mt <- t(X)
  misst.indices <- which(is.na(Mt))
  Mt[misst.indices] <- t(matrix(rep(colMeans(X, na.rm = TRUE), nrow(X)),
                                nrow = nrow(X),
                                byrow = TRUE))[misst.indices]
  cat("Spatial depth imputation:")
  for (i in 1:25){
    MtOld <- Mt
    a <- .C("ImputeSpatialOneIter",
            as.double(as.vector(Mt)),
            as.integer(ncol(Mt)),
            as.integer(nrow(Mt)),
            as.integer(misst.indices - 1),
            as.integer(length(misst.indices)),
            imputed = double(length(misst.indices)))
    Mt[misst.indices] <- a$imputed
    dif <- max(abs(MtOld - Mt))
    cat(" ", i, "(", round(dif, 6), ")", sep = "")
    if (dif < 0.001){break}
  }
  cat(".\n")
  return (t(Mt))
}

imp.depth.projection <- function(X, r = 10000){
  Mt <- t(X)
  misst.indices <- which(is.na(Mt))
  Mt[misst.indices] <- t(matrix(rep(colMeans(X, na.rm = TRUE), nrow(X)),
                                nrow = nrow(X),
                                byrow = TRUE))[misst.indices]
  cat("Projection depth (", r, " dirs) imputation:", sep = "")
  for (i in 1:30){
    MtOld <- Mt
    if (i == 1 || i == 6){
      a <- .C("ImputeProjectionOneIter",
              as.double(as.vector(Mt)),
              as.integer(ncol(Mt)),
              as.integer(nrow(Mt)),
              as.integer(misst.indices - 1),
              as.integer(length(misst.indices)),
              as.integer(0),
              as.integer(r),
              dirs = double(r * nrow(Mt)),
              imputed = double(length(misst.indices)))
      dirs <- a$dirs
    }else{
      a <- .C("ImputeProjectionOneIter",
              as.double(as.vector(Mt)),
              as.integer(ncol(Mt)),
              as.integer(nrow(Mt)),
              as.integer(misst.indices - 1),
              as.integer(length(misst.indices)),
              as.integer(1),
              as.integer(r),
              as.double(dirs),
              imputed = double(length(misst.indices)))
    }
    Mt[misst.indices] <- a$imputed
    dif <- max(abs(MtOld - Mt))
    cat(" ", i, "(", round(dif, 6), ")", sep = "")
    if (dif < 0.001){break}
  }
  cat(".\n")
  return (t(Mt))
}

imp.depth.zonoid.o <- function(X, rob = 1, hist = FALSE){
  Mt <- t(X)
  misst.indices <- which(is.na(Mt))
  miss.rows <- rowSums(is.na(X)) > 0.5
  Mt[misst.indices] <- t(matrix(rep(colMeans(X, na.rm = TRUE), nrow(X)),
                                nrow = nrow(X),
                                byrow = TRUE))[misst.indices]
  #cat("Zonoid depth imputation:")
  if (hist){
    ress <- list("")
    ress[[1]] <- t(Mt)
  }
  for (i in 1:25){
    # Save the previous-iteration data
    MtOld <- Mt
    # Separate points on the convex hull
    tMt <- t(Mt)
    rows.qh <- sort(unique(as.vector(convhulln(tMt))))
    miss.rows.qh <- which(miss.rows & (1:nrow(X) %in% rows.qh))
    misst.indices.qh <- which(t(matrix(rep(miss.rows & (1:nrow(X) %in% rows.qh),
                                           ncol(X)),
                                       ncol = ncol(X)) & is.na(X)))
    misst.indices <- which(t(!matrix(rep(miss.rows & (1:nrow(X) %in% rows.qh),
                                         ncol(X)), ncol = ncol(X)) & is.na(X)))
    # Impute the points on the convex hull if such exist
    qh.run <- FALSE
    if (length(misst.indices.qh) > 0 && i < 6){
      qh.run <- TRUE
      if (rob >= 0.99){
        w.est <- 0
      }else{
        mcd.est <- covMcd(tMt, alpha = rob)
        mcd.eig <- eigen(mcd.est$cov)
        w.est <- as.vector(mcd.eig$vectors %*% diag(1/sqrt(mcd.eig$values)))
      }
      a <- .C("ImputeSpatialOneIter",
              as.double(as.vector(Mt)),
              as.integer(ncol(Mt)),
              as.integer(nrow(Mt)),
              as.double(w.est),
              as.integer(misst.indices.qh - 1),
              as.integer(length(misst.indices.qh)),
              imputed = double(length(misst.indices.qh)))
      Mt[misst.indices.qh] <- a$imputed
    }else{
      misst.indices <- sort(c(misst.indices, misst.indices.qh))
    }
    # Input the points inside of the convex hull
    a <- .C("ImputeZonoidOneIter",
            as.double(as.vector(Mt)),
            as.integer(ncol(Mt)),
            as.integer(nrow(Mt)),
            as.integer(misst.indices - 1),
            as.integer(length(misst.indices)),
            imputed = double(length(misst.indices)))
    Mt[misst.indices] <- a$imputed
    if (hist){
      ress[[i + 1]] <- t(Mt)
    }
    # Check whether to continue
    dif <- max(abs(MtOld - Mt))
    cat(" ", i, "(", round(dif, 6), ifelse(qh.run, "qh", ""), ")", sep = "")
    if (dif < 0.00001){break}
  }
  cat(".\n")
  if (hist){
    return (list(X = t(Mt), hist = ress))
  }else{
    return (t(Mt))
  }
}

imp.depth.halfspace.o <- function(X, r = 1000, rob = 0.5){
  Mt <- t(X)
  misst.indices <- which(is.na(Mt))
  miss.rows <- rowSums(is.na(X)) > 0.5
  Mt[misst.indices] <- t(matrix(rep(colMeans(X, na.rm = TRUE), nrow(X)),
                                nrow = nrow(X),
                                byrow = TRUE))[misst.indices] +
    rnorm(n = length(misst.indices), mean = 0, sd = 0.001)
  cat("Tukey depth (", r, " dirs) imputation:", sep = "")
  for (i in 1:25){
    # Save the previous-iteration data
    MtOld <- Mt
    # Separate points on the convex hull
    tMt <- t(Mt)
    rows.qh <- sort(unique(as.vector(convhulln(tMt))))
    miss.rows.qh <- which(miss.rows & (1:nrow(X) %in% rows.qh))
    misst.indices.qh <- which(t(matrix(rep(miss.rows & (1:nrow(X) %in% rows.qh),
                                           ncol(X)),
                                       ncol = ncol(X)) & is.na(X)))
    misst.indices <- which(t(!matrix(rep(miss.rows & (1:nrow(X) %in% rows.qh),
                                         ncol(X)), ncol = ncol(X)) & is.na(X)))
    # Impute the points on the convex hull if such exist
    qh.run <- FALSE
    if (length(misst.indices.qh) > 0 && i < 6){
      qh.run <- TRUE
      if (rob >= 0.99){
        w.est <- 0
      }else{
        mcd.est <- covMcd(tMt, alpha = rob)
        mcd.eig <- eigen(mcd.est$cov)
        w.est <- as.vector(mcd.eig$vectors %*% diag(1/sqrt(mcd.eig$values)))
      }
      a <- .C("ImputeSpatialOneIter",
              as.double(as.vector(Mt)),
              as.integer(ncol(Mt)),
              as.integer(nrow(Mt)),
              as.double(w.est),
              as.integer(misst.indices.qh - 1),
              as.integer(length(misst.indices.qh)),
              imputed = double(length(misst.indices.qh)))
      Mt[misst.indices.qh] <- a$imputed
    }else{
      misst.indices <- sort(c(misst.indices, misst.indices.qh))
    }
    # Input the points inside of the convex hull
    if (i == 1 || i == 6){
      a <- .C("ImputeHalfspaceOneIter",
              as.double(as.vector(Mt)),
              as.integer(ncol(Mt)),
              as.integer(nrow(Mt)),
              as.integer(misst.indices - 1),
              as.integer(length(misst.indices)),
              as.integer(0),
              as.integer(r),
              dirs = double(r * nrow(Mt)),
              imputed = double(length(misst.indices)))
      dirs <- a$dirs
    }else{
      a <- .C("ImputeHalfspaceOneIter",
              as.double(as.vector(Mt)),
              as.integer(ncol(Mt)),
              as.integer(nrow(Mt)),
              as.integer(misst.indices - 1),
              as.integer(length(misst.indices)),
              as.integer(1),
              as.integer(r),
              as.double(dirs),
              imputed = double(length(misst.indices)))
    }
    Mt[misst.indices] <- a$imputed
    # Check whether to continue
    dif <- max(abs(MtOld - Mt))
    cat(" ", i, "(", round(dif, 6), ifelse(qh.run, "qh", ""), ")", sep = "")
    if (dif < 0.001){break}
  }
  cat(".\n")
  return (t(Mt))
}

imp.depth.halfspace.ex.o <- function(X, rob = 0.5){
  Mt <- t(X)
  misst.indices <- which(is.na(Mt))
  miss.rows <- rowSums(is.na(X)) > 0.5
  Mt[misst.indices] <- t(matrix(rep(colMeans(X, na.rm = TRUE), nrow(X)),
                                nrow = nrow(X),
                                byrow = TRUE))[misst.indices]
  cat("Tukey depth imputation:", sep = "")
  for (i in 1:19){
    # Save the previous-iteration data
    MtOld <- Mt
    # Separate points on the convex hull
    tMt <- t(Mt)
    rows.qh <- sort(unique(as.vector(convhulln(tMt))))
    miss.rows.qh <- which(miss.rows & (1:nrow(X) %in% rows.qh))
    misst.indices.qh <- which(t(matrix(rep(miss.rows & (1:nrow(X) %in% rows.qh),
                                           ncol(X)),
                                       ncol = ncol(X)) & is.na(X)))
    misst.indices <- which(t(!matrix(rep(miss.rows & (1:nrow(X) %in% rows.qh),
                                         ncol(X)), ncol = ncol(X)) & is.na(X)))
    # Impute the points on the convex hull if such exist
    qh.run <- FALSE
    if (length(misst.indices.qh) > 0 && i < 6){
      qh.run <- TRUE
      if (rob >= 0.99){
        w.est <- 0
      }else{
        mcd.est <- covMcd(tMt, alpha = rob)
        mcd.eig <- eigen(mcd.est$cov)
        w.est <- as.vector(mcd.eig$vectors %*% diag(1/sqrt(mcd.eig$values)))
      }
      a <- .C("ImputeSpatialOneIter",
              as.double(as.vector(Mt)),
              as.integer(ncol(Mt)),
              as.integer(nrow(Mt)),
              as.double(w.est),
              as.integer(misst.indices.qh - 1),
              as.integer(length(misst.indices.qh)),
              imputed = double(length(misst.indices.qh)))
      Mt[misst.indices.qh] <- a$imputed
    }else{
      misst.indices <- sort(c(misst.indices, misst.indices.qh))
    }
    # Input the points inside of the convex hull
    a <- .C("ImputeHalfspaceExOneIter",
            as.double(as.vector(Mt)),
            as.integer(ncol(Mt)),
            as.integer(nrow(Mt)),
            as.integer(misst.indices - 1),
            as.integer(length(misst.indices)),
            imputed = double(length(misst.indices)))
    Mt[misst.indices] <- a$imputed
    # Check whether to continue
    dif <- max(abs(MtOld - Mt))
    cat(" ", i, "(", round(dif, 6), ifelse(qh.run, "qh", ""), ")", sep = "")
    if (dif < 0.001){break}
  }
  cat(".\n")
  return (t(Mt))
}
