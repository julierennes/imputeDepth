#include "imputeDepth.h"

double LocalDepth(double* x, double** xx, int n, int d,
                  double locPar, DEPTHNOTION notion);
