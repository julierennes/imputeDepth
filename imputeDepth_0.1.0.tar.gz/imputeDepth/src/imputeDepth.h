/******************************************************************************/
/* File:             imputeDepth.h                                            */
/* Created by:       Pavlo Mozharovskyi                                       */
/* Last revised:     23.12.2016                                               */
/*                                                                            */
/* The general header for R-package imputeDepth.                              */
/*                                                                            */
/******************************************************************************/

#pragma once

#include <math.h>
#include <cstdlib>
#include <string.h>
#include <R_ext/Lapack.h>

using namespace std;

#include "common.h"
#include "depthCalc.h"
#include "CondOpt.h"
#include "shapeSVD.h"
#include "HD.h"
#include "imputation.h"
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/lu.hpp>
#include <boost/random.hpp>
extern "C" {
  #include "glpk.h"
}

#include <iostream>
